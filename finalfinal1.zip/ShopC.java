public class ShopC extends Drink{
	public ShopC() {
		  super();
		  setShopName("ShopC");
		 }
	public int compPrice() {
		  perprice=GT*30+BT*35+OT*40+bubble*10+milk*15;
		  price=perprice*num;
		  return price;
		 }
}

		 
  
  
 
 
 
 
 
 
